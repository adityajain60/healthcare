let Menu=document.querySelector("#menubtn");
let Navbar=document.querySelector(".navbar");
Menu.onclick=() => {
    Menu.classList.toggle("fa-times");
    Navbar.classList.toggle("active");
};